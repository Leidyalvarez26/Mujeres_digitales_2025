export type IUser = { id: number, name: string, email: string, password: string };// Define the IUser type
