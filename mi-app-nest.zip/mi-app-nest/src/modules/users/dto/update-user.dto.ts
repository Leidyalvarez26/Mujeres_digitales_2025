
import { CreateUserDto } from "./create-user.dto"; // Importa la clase CreateUserDto
export class UpdateUserDto extends CreateUserDto    { // Define la clase UpdateUserDto que extiende CreateUserDto
}
