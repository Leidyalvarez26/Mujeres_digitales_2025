export * from './IUser'; // Re export everything from the IUser.ts file
export * from './IProduct';// Re-export everything from the IProduct.ts file